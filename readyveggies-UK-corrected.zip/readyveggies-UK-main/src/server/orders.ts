import { createServerFn } from '@tanstack/react-start'
import { desc, eq } from 'drizzle-orm'
import { z } from 'zod'
import { db } from '../../db/index.js'
import { orders } from '../../db/schema.js'
import { productsById } from '@/data/products'
import { DELIVERY_DAYS, MIN_ORDER_PENCE, deliveryPenceFor, formatPence } from '@/lib/format'

const PaymentMethod = z.enum(['bank_transfer', 'paypal'])
const OrderStatus = z.enum(['new', 'confirmed', 'preparing', 'out_for_delivery', 'completed', 'cancelled'])
const PaymentStatus = z.enum(['pending', 'paid'])

const OrderInput = z.object({
  customerName: z.string().trim().min(2).max(120),
  email: z.string().trim().email().max(200),
  phone: z.string().trim().max(40).optional().or(z.literal('')),
  address: z.string().trim().min(6).max(400),
  postcode: z.string().trim().min(3).max(12),
  deliveryDay: z.enum(DELIVERY_DAYS),
  notes: z.string().trim().max(500).optional().or(z.literal('')),
  paymentMethod: PaymentMethod,
  items: z.array(z.object({ id: z.string(), qty: z.number().int().min(1).max(30) })).min(1).max(40),
})

export interface OrderLineSnapshot {
  id: string
  name: string
  unit: string
  qty: number
  pricePence: number
  linePence: number
}

function makeReference() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let code = ''
  for (let i = 0; i < 6; i++) code += alphabet[Math.floor(Math.random() * alphabet.length)]
  return `FF-${code}`
}

function emailConfig() {
  return {
    serviceId: process.env.EMAILJS_SERVICE_ID,
    templateId: process.env.EMAILJS_TEMPLATE_ID,
    publicKey: process.env.EMAILJS_PUBLIC_KEY,
    privateKey: process.env.EMAILJS_PRIVATE_KEY,
    sellerEmail: process.env.SELLER_ORDER_EMAIL || 'greenvallfarms@gmail.com',
  }
}

async function sendSellerOrderEmail(order: {
  reference: string
  customerName: string
  email: string
  phone: string | null
  address: string
  postcode: string
  deliveryDay: string
  notes: string | null
  paymentMethod: string
  items: OrderLineSnapshot[]
  subtotalPence: number
  deliveryPence: number
  totalPence: number
}) {
  const config = emailConfig()
  if (!config.serviceId || !config.templateId || !config.publicKey) {
    console.warn('EmailJS is not configured: EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID and EMAILJS_PUBLIC_KEY are required.')
    return false
  }

  const itemLines = order.items.map((item) => `${item.qty} × ${item.name} (${item.unit}) — ${formatPence(item.linePence)}`).join('\n')
  const paymentLabel = order.paymentMethod === 'paypal' ? 'PayPal (Friends & Family)' : 'Bank transfer'
  const response = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      service_id: config.serviceId,
      template_id: config.templateId,
      user_id: config.publicKey,
      accessToken: config.privateKey,
      template_params: {
        to_email: config.sellerEmail,
        order_reference: order.reference,
        customer_name: order.customerName,
        customer_email: order.email,
        customer_phone: order.phone || 'Not provided',
        delivery_address: `${order.address}, ${order.postcode}`,
        delivery_day: order.deliveryDay,
        payment_method: paymentLabel,
        order_items: itemLines,
        subtotal: formatPence(order.subtotalPence),
        delivery: order.deliveryPence === 0 ? 'Free' : formatPence(order.deliveryPence),
        total: formatPence(order.totalPence),
        customer_notes: order.notes || 'None',
      },
    }),
  })
  if (!response.ok) {
    console.error('EmailJS order notification failed:', await response.text())
    return false
  }
  return true
}

export const placeOrder = createServerFn({ method: 'POST' })
  .inputValidator(OrderInput)
  .handler(async ({ data }) => {
    const lines: Array<OrderLineSnapshot> = []
    for (const item of data.items) {
      const product = productsById.get(item.id)
      if (!product) continue
      lines.push({ id: product.id, name: product.name, unit: product.unit, qty: item.qty, pricePence: product.pricePence, linePence: product.pricePence * item.qty })
    }
    if (lines.length === 0) throw new Error('Your basket is empty.')

    const subtotalPence = lines.reduce((sum, l) => sum + l.linePence, 0)
    if (subtotalPence < MIN_ORDER_PENCE) throw new Error('Orders start at £15.00 — please add a little more.')
    const deliveryPence = deliveryPenceFor(subtotalPence)
    const reference = makeReference()

    const [row] = await db.insert(orders).values({
      reference, customerName: data.customerName, email: data.email, phone: data.phone || null,
      address: data.address, postcode: data.postcode.toUpperCase(), deliveryDay: data.deliveryDay,
      notes: data.notes || null, items: lines, subtotalPence, deliveryPence,
      totalPence: subtotalPence + deliveryPence, paymentMethod: data.paymentMethod,
      status: 'new', paymentStatus: 'pending',
    }).returning()

    const emailSent = await sendSellerOrderEmail({
      reference: row.reference, customerName: row.customerName, email: row.email, phone: row.phone,
      address: row.address, postcode: row.postcode, deliveryDay: row.deliveryDay, notes: row.notes,
      paymentMethod: row.paymentMethod, items: lines, subtotalPence: row.subtotalPence,
      deliveryPence: row.deliveryPence, totalPence: row.totalPence,
    })

    return { reference: row.reference, emailSent, paymentMethod: row.paymentMethod }
  })

const AdminInput = z.object({ password: z.string().min(1) })
function checkAdmin(password: string) {
  const expected = process.env.ADMIN_PASSWORD
  if (!expected || password !== expected) throw new Error('Invalid admin password.')
}

export const listOrders = createServerFn({ method: 'POST' })
  .inputValidator(AdminInput)
  .handler(async ({ data }) => {
    checkAdmin(data.password)
    const rows = await db.select().from(orders).orderBy(desc(orders.createdAt))
    return rows.map((row) => ({ ...row, createdAt: row.createdAt?.toISOString() ?? null }))
  })

export const updateOrder = createServerFn({ method: 'POST' })
  .inputValidator(AdminInput.extend({
    reference: z.string().min(3),
    status: OrderStatus.optional(),
    paymentStatus: PaymentStatus.optional(),
  }))
  .handler(async ({ data }) => {
    checkAdmin(data.password)
    let row: typeof orders.$inferSelect | undefined
    if (data.status) {
      ;[row] = await db.update(orders).set({ status: data.status }).where(eq(orders.reference, data.reference)).returning()
    } else if (data.paymentStatus) {
      ;[row] = await db.update(orders).set({ paymentStatus: data.paymentStatus }).where(eq(orders.reference, data.reference)).returning()
    } else {
      throw new Error('No update supplied.')
    }
    if (!row) throw new Error('Order not found.')
    return { reference: row.reference, status: row.status, paymentStatus: row.paymentStatus }
  })

export const getOrder = createServerFn({ method: 'GET' })
  .inputValidator((data: { reference: string }) => data)
  .handler(async ({ data }) => {
    const [row] = await db.select().from(orders).where(eq(orders.reference, data.reference)).limit(1)
    if (!row) return null
    return {
      reference: row.reference, customerName: row.customerName, email: row.email, phone: row.phone,
      address: row.address, postcode: row.postcode, deliveryDay: row.deliveryDay, notes: row.notes,
      paymentMethod: row.paymentMethod, status: row.status, paymentStatus: row.paymentStatus,
      items: row.items as Array<OrderLineSnapshot>, subtotalPence: row.subtotalPence,
      deliveryPence: row.deliveryPence, totalPence: row.totalPence, createdAt: row.createdAt?.toISOString() ?? null,
    }
  })
