import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { listOrders, updateOrder } from '@/server/orders'
import { formatPence } from '@/lib/format'

export const Route = createFileRoute('/admin')({ component: AdminPage })

type AdminOrder = Awaited<ReturnType<typeof listOrders>>[number]
const statuses = ['new','confirmed','preparing','out_for_delivery','completed','cancelled'] as const

function AdminPage() {
  const [password, setPassword] = useState('')
  const [orders, setOrders] = useState<AdminOrder[]>([])
  const [error, setError] = useState('')
  const [loaded, setLoaded] = useState(false)

  async function login(e: React.FormEvent) {
    e.preventDefault(); setError('')
    try { const rows = await listOrders({ data: { password } }); setOrders(rows); setLoaded(true) }
    catch (err) { setError(err instanceof Error ? err.message : 'Could not load orders.') }
  }

  async function change(reference: string, field: 'status' | 'paymentStatus', value: string) {
    try {
      if (field === 'status') {
        await updateOrder({ data: { password, reference, status: value as typeof statuses[number] } })
      } else {
        await updateOrder({ data: { password, reference, paymentStatus: value as 'pending' | 'paid' } })
      }
      setOrders((current) => current.map((order) => order.reference === reference ? { ...order, [field]: value } : order))
    } catch (err) { setError(err instanceof Error ? err.message : 'Could not update order.') }
  }

  if (!loaded) return <main className="mx-auto max-w-md px-5 py-20"><h1 className="font-display text-3xl font-bold text-farm-900">Order Management</h1><p className="mt-2 text-muted">Seller/admin access.</p><form onSubmit={login} className="mt-6 space-y-4 rounded-3xl border border-line bg-white p-6"><label className="block"><span className="text-sm font-bold">Admin password</span><input type="password" value={password} onChange={e => setPassword(e.target.value)} className="mt-1.5 w-full rounded-xl border border-line bg-cream px-4 py-3" required /></label>{error && <p className="text-sm font-semibold text-red-700">{error}</p>}<button className="w-full rounded-xl bg-farm-700 px-5 py-3 font-bold text-white">Open orders</button></form></main>

  return <main className="mx-auto max-w-7xl px-5 py-10"><div className="flex flex-wrap items-end justify-between gap-4"><div><h1 className="font-display text-3xl font-bold text-farm-900">Order Management</h1><p className="mt-1 text-muted">{orders.length} order(s)</p></div><button onClick={async () => setOrders(await listOrders({ data: { password } }))} className="rounded-xl border border-line bg-white px-4 py-2 text-sm font-bold">Refresh</button></div>{error && <p className="mt-4 rounded-xl bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">{error}</p>}<div className="mt-6 grid gap-5">{orders.map(order => <article key={order.reference} className="rounded-3xl border border-line bg-white p-5 shadow-sm"><div className="flex flex-wrap justify-between gap-3"><div><h2 className="font-bold text-farm-900">{order.reference} · {order.customerName}</h2><p className="text-sm text-muted">{order.email} · {order.phone || 'No phone'} · {order.createdAt ? new Date(order.createdAt).toLocaleString() : ''}</p></div><strong>{formatPence(order.totalPence)}</strong></div><div className="mt-4 grid gap-4 md:grid-cols-4"><div><p className="text-xs font-bold uppercase text-muted">Delivery</p><p className="text-sm">{order.deliveryDay}<br/>{order.address}, {order.postcode}</p></div><div><p className="text-xs font-bold uppercase text-muted">Payment</p><p className="text-sm">{order.paymentMethod === 'paypal' ? 'PayPal (Friends & Family)' : 'Bank transfer'}</p><select value={order.paymentStatus} onChange={e => change(order.reference, 'paymentStatus', e.target.value)} className="mt-2 rounded-lg border border-line px-2 py-1 text-sm"><option value="pending">Payment pending</option><option value="paid">Paid</option></select></div><div><p className="text-xs font-bold uppercase text-muted">Status</p><select value={order.status} onChange={e => change(order.reference, 'status', e.target.value)} className="mt-2 rounded-lg border border-line px-2 py-2 text-sm">{statuses.map(s => <option key={s} value={s}>{s.replaceAll('_',' ')}</option>)}</select></div><div><p className="text-xs font-bold uppercase text-muted">Items</p><p className="text-sm whitespace-pre-line">{(order.items as Array<{qty:number;name:string}>).map(i => `${i.qty} × ${i.name}`).join('\n')}</p></div></div>{order.notes && <p className="mt-4 rounded-xl bg-cream p-3 text-sm"><strong>Driver notes:</strong> {order.notes}</p>}</article>)}</div></main>
}
