import { Link, createFileRoute } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { getOrder } from '@/server/orders'
import { formatPence } from '@/lib/format'

export const Route = createFileRoute('/checkout/success')({ component: CheckoutSuccess })

function CheckoutSuccess() {
  const [order, setOrder] = useState<Awaited<ReturnType<typeof getOrder>> | null>(null)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const ref = params.get('ref')
    if (ref) getOrder({ data: { reference: ref } }).then(setOrder)
  }, [])

  return (
    <div className="min-h-screen flex items-center justify-center p-5">
      <div className="rounded-3xl p-8 sm:p-12 border border-line bg-white text-center max-w-xl w-full">
        <div className="text-6xl mb-6">✓</div>
        <h1 className="text-3xl font-bold mb-4 text-farm-900">Order Confirmed!</h1>
        <p className="mb-6 text-muted">Thank you for your order. We have recorded it and notified the farm by email when EmailJS is configured.</p>
        {order && (
          <div className="rounded-2xl bg-cream p-5 text-left">
            <p className="font-bold text-farm-900">Order {order.reference}</p>
            <p className="mt-2 text-sm">Delivery: <strong>{order.deliveryDay}</strong></p>
            <p className="text-sm">Payment: <strong>{order.paymentMethod === 'paypal' ? 'PayPal (Friends & Family)' : 'Bank transfer'}</strong></p>
            <p className="mt-2 text-lg font-bold">Total: {formatPence(order.totalPence)}</p>
            {order.paymentMethod === 'bank_transfer' ? (
              <div className="mt-4 rounded-xl border border-line bg-white p-4 text-sm">
                <strong>Bank transfer</strong>
                <p className="mt-1 text-muted">Add your farm's bank name, account name, account number and BSB/sort code here before publishing.</p>
                <p className="mt-1 font-semibold">Use your order reference {order.reference} as the payment reference.</p>
              </div>
            ) : (
              <div className="mt-4 rounded-xl border border-line bg-white p-4 text-sm">
                <strong>PayPal</strong>
                <p className="mt-1 text-muted">Send the payment using PayPal's Friends &amp; Family option where permitted, and include your order reference.</p>
                <p className="mt-1 font-semibold">PayPal email: greenvallfarms@gmail.com</p>
              </div>
            )}
          </div>
        )}
        <Link to="/" className="mt-8 inline-block px-6 py-3 rounded-xl bg-farm-700 text-white font-bold">Back to Home</Link>
      </div>
    </div>
  )
}
