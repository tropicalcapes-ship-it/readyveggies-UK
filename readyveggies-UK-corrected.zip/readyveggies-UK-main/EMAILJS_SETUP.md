# EmailJS + Order Management setup

## EmailJS
Create an EmailJS email template for seller order notifications and set its ID as `EMAILJS_TEMPLATE_ID`. The template can use these variables:

`{{to_email}}`, `{{order_reference}}`, `{{customer_name}}`, `{{customer_email}}`, `{{customer_phone}}`, `{{delivery_address}}`, `{{delivery_day}}`, `{{payment_method}}`, `{{order_items}}`, `{{subtotal}}`, `{{delivery}}`, `{{total}}`, `{{customer_notes}}`.

The server sends the notification to `greenvallfarms@gmail.com` through EmailJS. Keep the private key in Netlify environment variables; do not put it in browser code.

## Netlify environment variables
Set:
- `EMAILJS_SERVICE_ID=service_yjcymqe`
- `EMAILJS_TEMPLATE_ID=<your actual EmailJS template ID>`
- `EMAILJS_PUBLIC_KEY=8uor4YfhBlRNow4be`
- `EMAILJS_PRIVATE_KEY=<the EmailJS private key>`
- `SELLER_ORDER_EMAIL=greenvallfarms@gmail.com`
- `ADMIN_PASSWORD=<strong password>`

## Order management
Open `/admin` and enter `ADMIN_PASSWORD`. You can view orders, mark payment as paid, and change order status.

## Bank transfer details
The checkout currently shows a safe placeholder because no bank account details were supplied. Replace the placeholder in `src/routes/checkout/success.tsx` with the farm's actual bank name, account name, account number and BSB/sort code before publishing.

## PayPal
The checkout uses `greenvallfarms@gmail.com` as the displayed PayPal address and labels the method Friends & Family. Use that option only where permitted by PayPal's current terms and for the transaction type applicable to your business.
